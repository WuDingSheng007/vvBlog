$(function(){
	$("#scity,#sname,#stime1,#stime2").click(function(){
		$(this).css("background","#FCF5EA");
		$(this).css("border","1px solid #BB9861");
	})
	$("#stime1,#stime2").click(function(){
		$("#stime1,#stime2").css("background","#FCF5EA");
		$("#stime1,#stime2").css("border","1px solid #BB9861");
		$("#stime1").css("border-right","none");
		$("#stime2").css("border-left","none");
	})
	$("#scity").click(function(){
		$("#sname,#stime2,#stime1").css("background","white");
		$("#sname,#stime1,#stime2").css("border","1px solid #979797");
		$("#stime1").css("border-right","none");
		$("#stime2").css("border-left","none");
		$("#iaddr").show();
		$("#iname").hide();
		$("#itime1,#itime2").hide();
	})
	$("#sname").click(function(){
		$("#scity,#stime1,#stime2").css("background","white");
		$("#scity,#stime1,#stime2").css("border","1px solid #979797");
		$("#stime1").css("border-right","none");
		$("#stime2").css("border-left","none");
		$("#iaddr").hide();
		$("#iname").show();
		$("#itime1,#itime2").hide();
	})
	$("#stime1").click(function(){
		$("#sname,#scity").css("background","white");
		$("#sname,#scity").css("border","1px solid #979797");
		$("#iaddr").hide();
		$("#iname").hide();
		$("#itime1").show();
		$("#itime2").hide();
	})
	$("#stime2").click(function(){
		$("#sname,#scity").css("background","white");
		$("#sname,#scity").css("border","1px solid #979797");
		$("#iaddr").hide();
		$("#iname").hide();
		$("#itime2").show();
		$("#itime1").hide();
	})
	$(".head,.result").click(function(){
		$("#sname,#scity,#stime").css("background","white");
		$("#sname,#scity,#stime").css("border","1px solid #979797");
		$("#iaddr").hide();
		$("#iname").hide();
		$("#itime").hide();
	})
	$("#1,#addrimg1").hover(function(){
		$(this).css("background","#F9F8F6");
		$("#addrimg1").show();	
	},function(){
		$(this).css("background","white");
		$("#addrimg1").hide();	
	} )
	$("#2,#addrimg2").hover(function(){
		$(this).css("background","#F9F8F6");
		$("#addrimg2").show();
		
	},function(){
		$(this).css("background","white");
		$("#addrimg2").hide();
	
	} )
	$("#3,#addrimg3").hover(function(){
		$(this).css("background","#F9F8F6");
		$("#addrimg3").show();
	},function(){
		$(this).css("background","white");			
		$("#addrimg3").hide();
	} )
	$("#4,#addrimg4").hover(function(){
		$(this).css("background","#F9F8F6");
		$("#addrimg4").show();
	},function(){
		$(this).css("background","white");
		$("#addrimg4").hide();
	} )
	$("#5,#addrimg5").hover(function(){
		$(this).css("background","#F9F8F6");
		$("#addrimg5").show();
	},function(){
		$(this).css("background","white");
		$("#addrimg5").hide();
	} )
	$("#6,#addrimg6").hover(function(){
		$(this).css("background","#F9F8F6");
		$("#addrimg6").show();
	},function(){
		$(this).css("background","white");
		$("#addrimg6").hide();
	} )
	$(".middle_border").hover(function(){
		$("#addrimg2").hide();
		$("#addrimg1").hide();
		$("#addrimg3").hide();
		$("#addrimg4").hide();
	})
	$(".l3").hover(function(){
		$(this).css("color","black")
	},function(){
		$(this).css("color","#979797")
	}) 
	$(".l5,.l4,.area_2,.area_4").hover(function(){
		$(this).css("color","#C0191F")
	},function(){
		$(this).css("color","black")
	}) 
	$(".l5,.l4").click(function(){
		$(this).css("color","#C0191F")
	}) 
	$(".area_1").hover(function(){
		$(this).css("background-color","#C0191F")
		$(this).css("color","white")
	},function(){
		$(this).css("background-color","white")
		$(this).css("color","#535353")
	})
	$("#l_3").click(function(){
		$(".area1").show();
		$("#imga1").show();
		$(".area3").hide();
		$("#imga2").hide();
		$(".area5").hide();
	})
	$("#imga1").click(function(){
		$("#imga1").hide();
		$(".area1").hide();
	})
	 $("#l_2").click(function(){
		$(".area3").show();
		$(".area1").hide();
		$("#imga2").show();
		$("#imga1").hide();
		$(".area5").hide();
	})
	$("#imga2").click(function(){
		$(".area3").hide();
		$("#imga2").hide();
	}) 
	 $("#l_1").click(function(){
		$(".area2").show();
		$(".area4").hide();
	})
	$("#l_4").click(function(){
		$(".area2").hide();
		$(".area4").show();
	})
	$("#l_5").toggle(function(){
		$(".area5").show();
		$(".area3").hide();
		$(".area1").hide();
		$("#imga2").hide();
		$("#imga1").hide();
	},function(){
		$(".area5").hide();
	})
	$(".r2,.r3").hover(function(){
		$(this).css("color","#C0191F")
	},function(){
		$(this).css("color","black")
	})
	$(".log").hover(function(){
		$(this).css("background-color","#D4D4D4");
	},function(){
		$(this).css("background-color","white");
	})
	var day1,day2,month1,month2;
    $('#itime1').calendar({
        width: 440,
        height: 250,
        format: 'yyyy/mm/dd',
        onSelected: function (view, date, data) {     
        	var d = new Date(date);
        	var year = d.getFullYear();
        	month1 = d.getMonth()+1;
        	day1 = d.getDate();
        	var w =d.getDay();
        	if(w==0) {w=7};
            $("#stime1").val(year+"/"+month1+"/"+day1+"  星期-"+w+" 开始入住       ——"); 
        }
    });
	$('#itime2').calendar({
        width: 440,
        height: 250,
        format: 'yyyy/mm/dd',
        onSelected: function (view, date, data) {     
        	var d = new Date(date);
        	var year = d.getFullYear();
        	month2 = d.getMonth()+1;
        	day2 = d.getDate();
        	if(month1>month2){alert("选择日期冲突")}
        	else {if(day1>day2) {alert("选择日期冲突")}}
        	var w =d.getDay();
        	if(w==0) {w=7};
            $("#stime2").val(year+"/"+month2+"/"+day2+"  星期-"+w+" 离开"); 
        }
    });
    
	var map1 = new BMap.Map("addrimg1");
	var map2 = new BMap.Map("addrimg2");
	var map3 = new BMap.Map("addrimg3");
	var map4 = new BMap.Map("addrimg4");
	var map4 = new BMap.Map("addrimg5");
	var map4 = new BMap.Map("addrimg6");
	// 创建地图实例  
	var point1 = new BMap.Point(120.210242,30.167621);
	var point2 = new BMap.Point(119.045363,29.631306);
	var point3 = new BMap.Point(120.17106,30.26274);
	// 创建点坐标  
	map1.centerAndZoom(point1, 22);
	map2.centerAndZoom(point2, 22);
	map3.centerAndZoom(point3, 22);
	map4.centerAndZoom(point, 22);
	// 初始化地图，设置中心点坐标和地图级别  
	enableScrollWheelZoom(true);
	var marker = new BMap.Marker(point);        // 创建标注    
	map1.addOverlay(marker);    
	
})
