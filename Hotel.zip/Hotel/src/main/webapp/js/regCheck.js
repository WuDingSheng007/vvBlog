		$(document).ready(function(){
			$("#sub").click(function(){
				var $cltname = $("#cltName");
				if($cltname.val().length == 0){
					alert("用户名不能为空");
					return false;
				};
				var $pwd = $("#cltPswd");
				if($pwd.val().length < 6){
					alert("密码位数至少为6位");
					return false;
				};
				var $cltPswdConfirm = $("#cltPswdConfirm");
				if(!($cltPswdConfirm.val() == $pwd.val())){
					alert("两次输入的密码不同请重试");
					return false;
				};
				var $idCard = $("#cltIdCard"); 
				if($idCard.val().length != 18){
					alert("身份证号码必须为18位");
					return false;
				};
				var $phone = $("#cltTel");
				if($phone.val().length != 11){
					alert("请输入正确的电话");
					return false;
				};
				var isEmail = /^([a-zA-Z0-9_-])+@([a-zA-Z])+(.[a-zA-Z0-9_-])+/;
				var $cltEmail = $("#cltEmail");
				if(!(isEmail.test($cltEmail.val()))){
					alert("请输入正确的邮箱");
				}
				
			});
			$("#cltName").blur(function(){
				var $cltName = $("#cltName");
				if($cltName.val().length == 0){
					$("#span1").text("用户名不能为空");					
				};
				$cltName.focus(function () {
					$("#span1").text("");	
				})
			});
			$("#cltTel").blur(function(){
				var isphone = /^1[3|4|5|8][0-9]{9}/;
				var $phone = $("#cltTel");
				if(!(isphone.test($phone.val()))){
					$("#span2").text("输入正确的电话号码");					
				};
				$phone.focus(function () {
					$("#span2").text("");	
				})
			});
			$("#cltPswd").blur(function(){
				var $pwd = $("#cltPswd");
				if($pwd.val().length < 6 ||$pwd.val().length>20){
					$("#span3").text("密码必须大于六位");					
				};
				$pwd.focus(function () {
					$("#span3").text("");	
				})
			});
			$("#cltPswdConfirm").blur(function(){
				var $cltPswdConfirm = $("#cltPswdConfirm");
				var $pwd = $("#cltPswd");
				if(!($cltPswdConfirm.val() == $pwd.val())){
					$("#span4").text("两次输入密码必须相同");
				};
				$cltPswdConfirm.focus(function () {
					$("#span4").text("");	
				});
			});
	
			$("#cltIdCard").blur(function(){
				var $idCard = $("#cltIdCard");
				if($idCard.val().length != 18){
					$("#span5").text("身份证号码必须为18位");					
				};
				$idCard.focus(function () {
					$("#span5").text("");	
				})
			});
			
			$("#cltEmail").blur(function(){
				var isEmail = /^([a-zA-Z0-9_-])+@([a-zA-Z])+(.[a-zA-Z0-9_-])+/;
				var $cltEmail = $("#cltEmail");
				if(!(isEmail.test($cltEmail.val()))){
					
					$("#span6").text("错误的邮箱格式");
				}
				$cltEmail.focus(function () {
					$("#span6").text("");	
				})
			});
			$("#getEmailCode").click(function(){
				$.ajax({
					type: 'post',
					url : 'MailLogin.do',
					dataType : 'text',
					data:{
						"cltEmail": $("#cltEmail").val()
					},
					success : function(Result) {
										
					} ,
					error : function(xhr, status, errMsg)
			        {
			             alert("数据传输失败!");
			        }
				
			});
				/*$("[name='check']").val("need");
				$("#form1").submit();*/
			})
		});