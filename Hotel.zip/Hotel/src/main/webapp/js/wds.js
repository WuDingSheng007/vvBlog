$(document).ready(function() {
	alert("aa");
	$(".msg").hide();
	$(".showOrder").bind("click", function() {
		$(".msg").hide();
		$(".order").show();
	});
	$(".showMsg").bind("click", function() {
		$(".order").hide();
		$(".msg").show();
	});
});