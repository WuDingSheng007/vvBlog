$(document).ready(function() {
	$(".msg").hide();
	$(".showOrder").bind("click", function() {
		$(".msg").hide();
		$(".order").show();
	});
	$(".showMsg").bind("click", function() {
		$(".order").hide();
		$(".msg").show();
	});
	$(".change1").bind("click", function() {
		$(".change1").hide();
		$(".myName").removeProp("readonly");
	});
	$(".change2").bind("click", function() {
		$(".change2").hide();
		$(".myTel").removeProp("readonly");
	});
	$(".change3").bind("click", function() {
		$(".change3").hide();
		$(".myEmail").removeProp("readonly");
	});
	$(".change4").bind("click", function() {
		$(".change4").hide();
		$(".myIdCard").removeProp("readonly");
	});
});