package com.erase.dao;


import java.util.List;

import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.erase.bean.Client;
import com.erase.bean.Order;



public interface MsgMapper {
	@Update("update client set clt_name=#{clt_Name },clt_tel=#{clt_Tel },clt_email=#{clt_Email },clt_idcard=#{clt_IdCard } where clt_id=#{clt_id }")
	void changeMsg(Client clt);
	@Select("select order_id orderId,order_hotel_id orderHotelId,order_room_type orderRoomType,order_clt_inDay orderCltInday,order_clt_outDay orderCltOutday,order_price orderPrice"
			+ " from client join clt_order on clt_id=order_clt_id where clt_id=#{clt_id } and order_clt_inDay >= now() order by order_clt_outDay desc")
	List<Order> queryOrder(Client clt);
	@Select("select order_id orderId,order_hotel_id orderHotelId,order_room_type orderRoomType,order_clt_inDay orderCltInday,order_clt_outDay orderCltOutday,order_price orderPrice"
			+ " from client join clt_order on clt_id=order_clt_id where clt_id=#{clt_id } and order_clt_inDay < now() order by order_clt_outDay desc")
	List<Order> queryOrder2(Client clt);
}