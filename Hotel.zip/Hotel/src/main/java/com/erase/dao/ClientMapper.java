package com.erase.dao;

import com.erase.bean.Client;

public interface ClientMapper {
	int insertClient(Client clt);
	Client loginCheck(Client clt);
}
