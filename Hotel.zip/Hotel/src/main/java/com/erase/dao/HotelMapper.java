package com.erase.dao;

import java.util.List;

import com.erase.bean.Hotel;

public interface HotelMapper {

	//public List<Hotel> getHotel(String name,String addr);
	//public List<Hotel> getHotel(String name);
	public List<Hotel> getHotel(Hotel hotel);

	public List<Hotel> orderByPrice(Hotel hotel);

	public List<Hotel> oPage(Hotel hotel,int page);

}
