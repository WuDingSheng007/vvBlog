package com.erase.bean;

public class Client {
	private int clt_id;
	private String clt_No;
	private String clt_Name;
	private String clt_Tel;
	private String clt_Email;
	private String clt_IdCard;
	private String clt_Pswd;
	
	@Override
	public String toString() {
		return "Client [cltId=" + clt_id + ", cltNo=" + clt_No + ", cltName="
				+ clt_Name + ", cltTel=" + clt_Tel + ", cltEmail=" + clt_Email
				+ ", cltIdCard=" + clt_IdCard + ", cltPswd=" + clt_Pswd + "]";
	}
	public Client() {
		super();
	}
	public Client(int cltId, String cltNo, String cltName, String cltTel,
			String cltEmail, String cltIdCard, String cltPswd) {
		super();
		this.clt_id = cltId;
		this.clt_No = cltNo;
		this.clt_Name = cltName;
		this.clt_Tel = cltTel;
		this.clt_Email = cltEmail;
		this.clt_IdCard = cltIdCard;
		this.clt_Pswd = cltPswd;
	}
	public int getClt_id() {
		return clt_id;
	}
	public void setClt_Id(int clt_id) {
		this.clt_id = clt_id;
	}
	public String getClt_No() {
		return clt_No;
	}
	public void setClt_No(String clt_No) {
		this.clt_No = clt_No;
	}
	public String getClt_Name() {
		return clt_Name;
	}
	public void setClt_Name(String clt_Name) {
		this.clt_Name = clt_Name;
	}
	public String getClt_Tel() {
		return clt_Tel;
	}
	public void setClt_Tel(String clt_Tel) {
		this.clt_Tel = clt_Tel;
	}
	public String getClt_Email() {
		return clt_Email;
	}
	public void setClt_Email(String clt_Email) {
		this.clt_Email = clt_Email;
	}
	public String getClt_IdCard() {
		return clt_IdCard;
	}
	public void setClt_IdCard(String clt_IdCard) {
		this.clt_IdCard = clt_IdCard;
	}
	public String getClt_Pswd() {
		return clt_Pswd;
	}
	public void setClt_Pswd(String clt_Pswd) {
		this.clt_Pswd = clt_Pswd;
	}
}
