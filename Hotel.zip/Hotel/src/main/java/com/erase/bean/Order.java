package com.erase.bean;

public class Order {
	private Integer orderId;
	private Integer orderHotelId;
	private Integer orderCltId;
	private String orderRoomType;
	private String orderCltInday;
	private String orderCltOutday;
	private String orderPrice;
	public Integer getOrderId() {
		return orderId;
	}
	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}
	public Integer getOrderHotelId() {
		return orderHotelId;
	}
	public void setOrderHotelId(Integer orderHotelId) {
		this.orderHotelId = orderHotelId;
	}
	public Integer getOrderCltId() {
		return orderCltId;
	}
	public void setOrderCltId(Integer orderCltId) {
		this.orderCltId = orderCltId;
	}
	public String getOrderRoomType() {
		return orderRoomType;
	}
	public void setOrderRoomType(String orderRoomType) {
		this.orderRoomType = orderRoomType;
	}
	public String getOrderCltInday() {
		return orderCltInday;
	}
	public void setOrderCltInday(String orderCltInday) {
		this.orderCltInday = orderCltInday;
	}
	public String getOrderCltOutday() {
		return orderCltOutday;
	}
	public void setOrderCltOutday(String orderCltOutday) {
		this.orderCltOutday = orderCltOutday;
	}
	public String getOrderPrice() {
		return orderPrice;
	}
	public void setOrderPrice(String orderPrice) {
		this.orderPrice = orderPrice;
	}
	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", orderHotelId=" + orderHotelId
				+ ", orderCltId=" + orderCltId + ", orderRoomType="
				+ orderRoomType + ", orderCltInday=" + orderCltInday
				+ ", orderCltOutday=" + orderCltOutday + ", orderPrice="
				+ orderPrice + "]";
	}
	public Order() {
		super();
	}
}
