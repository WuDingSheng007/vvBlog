package com.erase.bean;

public class Hotel {
	   private int hotel_id;
	   private String hotel_name;
	   private String hotel_addr;
	   private double hotel_lowprice;
	   private String hotel_memo;
	   private String hotel_imgs;
	public String getHotel_imgs() {
		return hotel_imgs;
	}
	public void setHotel_imgs(String hotel_imgs) {
		this.hotel_imgs = hotel_imgs;
	}
	public int getHotel_id() {
		return hotel_id;
	}
	public void setHotel_id(int hotel_id) {
		this.hotel_id = hotel_id;
	}
	public String getHotel_name() {
		return hotel_name;
	}
	public void setHotel_name(String hotel_name) {
		this.hotel_name = hotel_name;
	}
	public String getHotel_addr() {
		return hotel_addr;
	}
	public void setHotel_addr(String hotel_addr) {
		this.hotel_addr = hotel_addr;
	}
	public double getHotel_lowprice() {
		return hotel_lowprice;
	}
	public void setHotel_lowprice(double hotel_lowprice) {
		this.hotel_lowprice = hotel_lowprice;
	}
	public String getHotel_memo() {
		return hotel_memo;
	}
	public void setHotel_memo(String hotel_memo) {
		this.hotel_memo = hotel_memo;
	}
	@Override
	public String toString() {
		return "Hotel [hotel_id=" + hotel_id + ", hotel_name=" + hotel_name
				+ ", hotel_addr=" + hotel_addr + ", hotel_lowprice="
				+ hotel_lowprice + ", hotel_memo=" + hotel_memo +",hotel_imgs"+hotel_imgs+ "]";
	}
	   
	   
}
