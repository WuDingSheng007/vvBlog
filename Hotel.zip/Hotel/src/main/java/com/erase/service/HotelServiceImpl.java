package com.erase.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.erase.bean.Hotel;
import com.erase.dao.HotelMapper;

@Service("hotelService")
public class HotelServiceImpl implements HotelService{
	@Autowired
	private HotelMapper hotelMapper;
	@Override
	public List<Hotel> getHotel(Hotel hotel) {
		List<Hotel> list = hotelMapper.getHotel(hotel);
		System.out.println(list);
		return list;
	}
	@Override
	public List<Hotel> orderByPrice(Hotel hotel) {
		List<Hotel> list = hotelMapper.orderByPrice(hotel);
		System.out.println(hotel);
		System.out.println(list);
		return list;
	}
	@Override
	public List<Hotel> oPage(Hotel hotel,int page) {
		List<Hotel> list = hotelMapper.oPage(hotel,page);
		return list;
	}


}
