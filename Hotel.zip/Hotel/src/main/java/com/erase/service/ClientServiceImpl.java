package com.erase.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.erase.bean.Client;
import com.erase.dao.ClientMapper;


@Service
public class ClientServiceImpl implements ClientService{
	@Autowired
	ClientMapper clientMapper;
	@Override
	public int insertOne(Client clt) {
		
		return clientMapper.insertClient(clt);
	}
	@Override
	public Client loginCheck(Client clt) {
		return clientMapper.loginCheck(clt);
	}

}
