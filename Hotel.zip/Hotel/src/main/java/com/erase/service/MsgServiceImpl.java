package com.erase.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.erase.bean.Client;
import com.erase.bean.Order;
import com.erase.dao.MsgMapper;



@Service("msgService")
public class MsgServiceImpl implements MsgService {
	@Autowired
	private MsgMapper msgMapper;


	public void changeMsg(Client clt) {
		// TODO Auto-generated method stub
		 msgMapper.changeMsg(clt);
	}
	public List<Order> queryOrder(Client clt){
		System.out.println(msgMapper.queryOrder(clt));
		return msgMapper.queryOrder(clt);
	}
	public List<Order> queryOrder2(Client clt){
		System.out.println(msgMapper.queryOrder(clt));
		return msgMapper.queryOrder2(clt);
	}
	public MsgServiceImpl() {
		System.out.println("MsgServiceImpl 构造方法");
	}
}