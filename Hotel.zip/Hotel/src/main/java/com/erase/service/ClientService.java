package com.erase.service;

import com.erase.bean.Client;



public interface ClientService {
	int insertOne(Client clt);
	Client loginCheck(Client clt);
}
