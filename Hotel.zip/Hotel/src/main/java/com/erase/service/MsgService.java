package com.erase.service;

import java.util.List;

import com.erase.bean.Client;
import com.erase.bean.Order;


public interface MsgService {
	public void changeMsg(Client clt);
	public List<Order> queryOrder(Client clt);
	public List<Order> queryOrder2(Client clt);
}
