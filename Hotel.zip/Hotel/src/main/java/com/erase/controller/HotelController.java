package com.erase.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.erase.bean.Hotel;
import com.erase.service.HotelService;

@Controller
public class HotelController {
	   @Autowired
	   private HotelService hotelService;
	  // private int pageSize = 3;
	   @RequestMapping(value = "/getHotel.do",produces = "text/plain;charset=utf-8")
	   public String queryGoods(Hotel hotel,String s,Model model, HttpSession session){
		      String hotel_name = "%"+hotel.getHotel_name()+"%";
		      String hotel_addr = "%"+hotel.getHotel_addr()+"%";
		      hotel.setHotel_name(hotel_name);
		      hotel.setHotel_addr(hotel_addr);
			  List<Hotel> listhotel = hotelService.getHotel(hotel);
			  System.out.println(hotel);
			  model.addAttribute("listhotel", listhotel); 
			  int pageNow = 0;
			  model.addAttribute("page", pageNow); 
			  return "search";
	  } 
	  @RequestMapping(value = "/orderByPrice.do",produces = "text/plain;charset=utf-8")
	  public String orderByPrice(Hotel hotel,Model model){
		 	 String hotel_name = "%"+hotel.getHotel_name()+"%";
		 	 String hotel_addr = "%"+hotel.getHotel_addr()+"%";
		 	 hotel.setHotel_name(hotel_name);
		 	 hotel.setHotel_addr(hotel_addr);
		     List<Hotel> listhotel = hotelService.orderByPrice(hotel);
		     int pageNow = 0;
			 model.addAttribute("page", pageNow); 
		     model.addAttribute("listhotel", listhotel); 
		     return "search";	  
	  }
	  @RequestMapping(value = "/oPage.do",produces = "text/plain;charset=utf-8")
	  public String oPage(int pageNow,Hotel hotel,Model model){
		     String hotel_name = "%"+hotel.getHotel_name()+"%";
		 	 String hotel_addr = "%"+hotel.getHotel_addr()+"%";
		 	 hotel.setHotel_name(hotel_name);
		 	 hotel.setHotel_addr(hotel_addr);
		     int page =0;
		     page = pageNow*3;
		     if(pageNow<=0){
		    	 page = 0;
		     }
		     System.out.println(page);
		     System.out.println(hotel.getHotel_addr());
		     List<Hotel> listhotel = hotelService.oPage(hotel,page);
		     System.out.println( listhotel);
		     model.addAttribute("listhotel", listhotel); 
		     model.addAttribute("page", pageNow); 
		     return "search";
	  }
}
