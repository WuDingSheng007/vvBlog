package com.erase.controller;



import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.erase.bean.Client;
import com.erase.bean.Order;
import com.erase.service.MsgService;



@Controller
public class MsgController {
	@Autowired
	private MsgService msgService;
	@RequestMapping("/userMsgSave.do")
	public String changeMsg(Client clt,HttpSession session,Model model) {
		Client clt1=(Client) session.getAttribute("Client");
		clt.setClt_Id(clt1.getClt_id());
		System.out.println("上传："+clt);
		msgService.changeMsg(clt);
		session.removeAttribute("loginName");
		System.out.println("cltName:"+ clt.getClt_Name());
		session.setAttribute("loginName", clt.getClt_Name());
		return "userView/userMsg";
	}
	@RequestMapping("/queryOrder.do")
	public String queryOrder(HttpSession session,Model model) {
		Client clt = (Client)session.getAttribute("Client");
		System.out.println(clt +":查询订单");	
		List<Order> orderList=msgService.queryOrder(clt);
		//model.addAttribute("Client",clt);
		System.out.println("orderList:"+orderList);
		model.addAttribute("OrderList",orderList);
		return "userView/userMsg";
	}
	@RequestMapping("/queryOrder2.do")
	public String queryOrder2(HttpSession session,Model model) {
		Client clt = (Client)session.getAttribute("Client");
		System.out.println(clt +":查询历史订单");	
		List<Order> orderList2=msgService.queryOrder2(clt);
		//model.addAttribute("Client",clt);
		System.out.println("orderList2:"+orderList2);
		model.addAttribute("OrderList2",orderList2);
		return "userView/userMsg";
	}
}
