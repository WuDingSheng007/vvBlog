package com.erase.controller;

public class Checkroom {
	public String showhotel(int hotelId){
		return "";
	}
}
