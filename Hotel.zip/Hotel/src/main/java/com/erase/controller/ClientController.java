package com.erase.controller;

import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.erase.bean.Client;
import com.erase.service.ClientService;
@Controller
public class ClientController {
	@Autowired
	ClientService clientService;
	@RequestMapping("/rjRegSave.do")
	public String insertClt(Client clt,String EmailCode,String check,HttpSession session,HttpServletRequest request) throws Exception{
		session.removeAttribute("Client");
		session.setAttribute("Client", clt);
		Object attribute = session.getAttribute("RsgCode");
		if(attribute == null&& attribute.toString().length()==0){
			System.out.println("请输入验证码");
			return "rjClientRsg";
		}else{
			String code = String.valueOf(attribute);
			if(code.equals(EmailCode)){
				session.removeAttribute("Client");
				session.removeAttribute("RsgCode");
				int rel = clientService.insertOne(clt);
				System.out.println(rel);
				return "clientLogin";
			}else{
				System.out.println("验证不匹配"+ code +" "+ EmailCode);
				return "rjClientRsg";
			}
		}
		
	}
	@RequestMapping("/clientLogin.do")
	public String loginCheck(Client clt, Model model ,HttpSession session){
		System.out.println(clt);
		Client client = clientService.loginCheck(clt);
		System.out.println(client);
		if(client != null && (client.getClt_Name()!= null || client.getClt_Tel()!=null)){
			session.setAttribute("loginName", client.getClt_Name());
			session.setAttribute("Client", client);
			return "index";
		}else{
			session.removeAttribute("loginNo");
			model.addAttribute("errMsg","登录不成功,请核对账号密码是否正确");
			return "clientLogin";
		}
	}
	@RequestMapping("/MailLogin.do")
	 public String mailSucc(HttpServletRequest request,Model model,HttpSession session) throws Exception{
        
        String code = String.format("%04d",new Random().nextInt(9999));
        String toEMAIL = request.getParameter("cltEmail");         //对方邮箱
        String TITLE = "如家会员欢迎你的加入";       //标题
        String CONTENT ="本次如家注册验证码为:"+"\n"+code;        //内容
        JavaEmailSender.sendEmail(toEMAIL, TITLE, CONTENT);
        session.setAttribute("RsgCode", code);
       return "rjClientRsg";
       
   }
	@RequestMapping("/logout.do")
	public String logout(Client clt,String EmailCode,HttpSession session,HttpServletRequest request) throws Exception{
		session.removeAttribute("Client");
		session.removeAttribute("loginName");
		System.out.println(12);
		return "index";
	}
}
