$(function(){
	$("#logout").click(function(){
		return confirm("确认退出登录？");
	});
});