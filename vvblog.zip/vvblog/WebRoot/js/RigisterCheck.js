$(function() {
	$("[name='usrNo']").bind('input propertychange',function() {
		$.ajax({
			url : 'userNoCheck',
			dataType : 'text',
			data:{
			'usrNo':$(this).val()
			},
			success : function(data) {
			console.log("data:"+data);
			if (data == 'has'){
			$("[name='usrNo']").after($("<span id='userNoMsg' style='color:red'>此账号已被注册</span>"));
			}
			},
			error:function(data){
			//alert("error:"+data);
			console.log(data);
			}
			});
			});
			$("[name='usrNo']").focus(function() {
			$("#usrNoMsg").remove();
			});
		});