$(function(){
    $("[name ='follow']").bind('click',function () {
        var amsj = $(this).find("[name ='usrid']").val();
        var a = $(this).find("[name ='usra']");
        $.ajax({
            url:"/vvblog/addfollow",
            data:{usrId :amsj },
            success:function (data) {
                if (data == '1'){
                    a.text("已关注");
                }else{
                    a.text("关注");
                }
            },
            error:function () {
                alert("未登录不能关注")
            }
        })
    })
});
function reSuccess(message){
    alert(message);
}