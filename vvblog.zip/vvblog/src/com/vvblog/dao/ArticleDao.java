package com.vvblog.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.vvblog.jdbc.DbUtil;
import com.vvblog.domain.Article;
import com.vvblog.domain.Comment;

/**
 * @program: vvblog
 * @description: Article数据库层操作
 * @author 作者: Chen gm
 * @version 创建时间：2019年8月9日 下午4:09:38
 */
public class ArticleDao {


	public int insertAritcle(Article article) {
		String sql = "INSERT INTO atc_article(atc_usr_id,atc_title,atc_cont,atc_img_path)VALUE(?,?,?,?)";
		Object[] params = { article.getActUserId(), article.getAtcTitle(), article.getAtcCont(),article.getAtcImgPath()};
		System.out.println("dao层测试数据："+article.getActUserId()+article.getAtcTitle()+article.getAtcCont()+article.getAtcImgPath());


		return DbUtil.update(sql, params);

	}

	public int selectatcIdByArticle(Article article) {
		String sql = "select atc_id from atc_article where atc_usr_id = ?";

		Object[] params = { article.getActUserId() };
		ResultSet rs = DbUtil.query(sql, params);
		try {
			if (rs.next()) {
				return rs.getInt("atc_id");
			}
			return 0;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}

	public Article showArticleByActId(int actId) {

		String sql = "SELECT * FROM atc_article WHERE atc_id = ? ";
		String sql2 = "UPDATE atc_article SET atc_acc = atc_acc+1 WHERE atc_id = ?" ;
		Object[] params = { actId };

		ResultSet rs = DbUtil.query(sql, params);
		try {
			if (rs.next()) {
				Article artile = new Article();
				artile.setAtcId(rs.getInt("atc_id"));
				artile.setActUserId(rs.getInt("atc_usr_id"));
				artile.setAtcTitle(rs.getString("atc_title"));
				artile.setAtcCont(rs.getString("atc_cont"));
				artile.setAtcImgPath(rs.getString("atc_img_path"));
				artile.setAtcLike(rs.getString("atc_like"));
				artile.setAtcAcc(rs.getInt("atc_acc"));
				artile.setAtcTime(rs.getString("atc_time"));
				DbUtil.update(sql2, params);
				return artile;
			}
			return null;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	public List<Article> selectallArticleByUseid(int usrId) {
		String sql = "SELECT * FROM atc_article LEFT JOIN usr_user ON usr_id = atc_usr_id HAVING usr_id = ?";
		Object[] params = { usrId };
		ResultSet rs = DbUtil.query(sql, params);
		List<Article> articleList = new ArrayList<Article>();
		try {
			while (rs.next()) {
				Article artile = new Article();
				artile.setAtcId(rs.getInt("atc_id"));
				artile.setActUserId(rs.getInt("atc_usr_id"));
				artile.setAtcTitle(rs.getString("atc_title"));
				artile.setAtcCont(rs.getString("atc_cont"));
				artile.setAtcImgPath(rs.getString("atc_img_path"));
				artile.setAtcLike(rs.getString("atc_like"));
				artile.setAtcAcc(rs.getInt("atc_acc"));
				artile.setAtcTime(rs.getString("atc_time"));
				articleList.add(artile);
				System.out.println(artile.toString());
			}
			return articleList;

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	public int deleteArticleByatcAId(int atcId) {
		String sql = "DELETE FROM atc_article WHERE atc_id = ?";
		Object[] params = { atcId };
		int rel = DbUtil.update(sql, params);
		if (rel == 1) {
			return rel;
		}
		return 0;
	}

	public int updateArticleByActId(int atcId) {
		String sql = "UPDATE atc_article SET atc_title = ?,atc_cont=?,atc_img_path=? where atc_id = ?";
		Object[] params = {};
		return 0;
	}

	public int ploadPictureSave(int atcId, String fileName) {
		String sql = "UPDATE atc_article SET atc_img_path = ? WHERE atc_id = ? ";
		Object[] params = { atcId, fileName };
		int rel = DbUtil.update(sql, params);
		if (rel == 1) {
			return rel;
		}
		return 0;
	}

	public List<Comment> selectCommList(int actId) {
		String sql = "SELECT *FROM cmt_comment WHERE cmt_art_id = ? ORDER BY cmt_time DESC";
		Object[] params = { actId };

		ResultSet rs = DbUtil.query(sql, params);
		List<Comment> comList = new ArrayList<Comment>();
		try {
			while (rs.next()) {
				Comment com = new Comment();
				com.setCmtId(rs.getInt("cmt_id"));
				com.setCmtCont(rs.getString("cmt_cont"));
				com.setCmtArtId(rs.getString("cmt_art_id"));
				com.setCmtTime(rs.getString("cmt_time"));
				com.setCmtLike(rs.getString("cmt_like"));
				com.setCmtUsrId(rs.getInt("cmt_usr_id"));
				comList.add(com);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return comList;
	}


	public int selectCount() {
		String sql = "SELECT count(*) cnt FROM atc_article ";
		ResultSet rs = DbUtil.query(sql, null);

		try {
			if (rs.next())
				return rs.getInt("cnt");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}
	public List<Article> selectInfo(Map<String, Object> map) {
		String sql = "SELECT* FROM atc_article \n" +
				"ORDER BY  atc_time DESC LIMIT ?,?";
		Object[] params = {map.get("page"),map.get("size")};
		ResultSet rs = DbUtil.query(sql, params);
		List<Article> articles = new ArrayList<>();
		try {
			while (rs.next()) {
				Article artile = new Article();
				artile.setAtcId(rs.getInt("atc_id"));
				artile.setActUserId(rs.getInt("atc_usr_id"));
				artile.setAtcTitle(rs.getString("atc_title"));
				artile.setAtcCont(rs.getString("atc_cont"));
				artile.setAtcImgPath(rs.getString("atc_img_path"));
				artile.setAtcLike(rs.getString("atc_like"));
				artile.setAtcAcc(rs.getInt("atc_acc"));
				artile.setAtcTime(rs.getString("atc_time"));
				articles.add(artile);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return articles;
	}

	public int insertComm(String cont, int atcId, int usrId) {
		String sql = "INSERT INTO cmt_comment(cmt_cont,cmt_art_id,cmt_usr_id)VALUES(?,?,?)";
		Object[] params = {cont,atcId,usrId};
		return DbUtil.update(sql, params);
	}
}
