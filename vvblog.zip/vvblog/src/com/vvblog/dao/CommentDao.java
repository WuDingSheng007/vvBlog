package com.vvblog.dao;

import com.vvblog.domain.Comment;

/**
 * @program: vvblog
 * @description: Comment数据库层操作
 * @create: 2019-08-09
 */
public class CommentDao {
	public Comment selectCommentById(Integer commentId) {
		return null;
	}
}
