package com.vvblog.dao;

import com.vvblog.domain.Manage;

/**
 * @program: vvblog
 * @description: Manage数据库层操作
 * @create: 2019-08-09
 */
public class ManageDao {
	public Manage selectManageById(Integer manageId) {
		return null;
	}
}
