package com.vvblog.dao;

import com.vvblog.jdbc.DbUtil;
import com.vvblog.domain.Attention;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/** 
*
* @version 创建时间：2019年8月9日 下午4:18:33 
*/
public class AttentionDao {

	public Attention selectAttentionById(Integer attId) {
		// TODO Auto-generated method stub
		return null;
	}
	//创建关注状态
	public int addAtt(Integer attId,Integer attFrdId){
		String sql = "insert into att_attention(att_usr_id, att_usr_frd_id) values(?, ?)";
		Object[] prams = {attId,attFrdId};
		return DbUtil.update(sql,prams);
	}
	public boolean selAtt(Integer attId,Integer attFrdId){
		String sql = "select * from att_attention where att_usr_id = ? and att_usr_frd_id = ?";
		Object[] prams = {attId,attFrdId};
		ResultSet rs = DbUtil.query(sql, prams);
		try {
			if (rs.next())
				return true;
		} catch (SQLException ignored) {

		}
		return false;
	}
	public List<Integer> selAtt(Integer attId){
		String sql = "select att_usr_frd_id from att_attention where att_usr_id = ?";
		Object[] prams = {attId};
		ResultSet rs = DbUtil.query(sql, prams);
		List<Integer> integers = new ArrayList<Integer>();
		try {
			while (rs.next()){
				integers.add(rs.getInt("att_usr_frd_id"));
			}
		} catch (SQLException ignored) {

		}
		return integers;
	}
	public int delAtt(Integer attId,Integer attFrdId){
		String sql = "DELETE FROM att_attention where att_usr_id = ? and att_usr_frd_id = ?";
		Object[] prams = {attId,attFrdId};
		return DbUtil.update(sql,prams);
	}

}
