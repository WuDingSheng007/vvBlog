package com.vvblog.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.vvblog.domain.User;
import com.vvblog.jdbc.DbUtil;

/**
 * @program: vvblog
 * @description: User数据库层操作
 * @create: 2019-08-09 
 */
public class UserDao {

	public User selectUserById(Integer usrId) {
		return null;
	}

	public int loginCheck(String usrNo, String usrPswd) {
		//登录验证
		String sql = "select usr_id from usr_user where usr_no=? and usr_pswd=md5(?)";
		Object[] params = {usrNo,usrPswd};
		ResultSet rs = DbUtil.query(sql, params);
		try {
			if (rs.next()) {
				return rs.getInt("usr_id");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}
	public int getUsrPer(String usrNo) {
		//登录验证
		String sql = "select usr_per from usr_user where usr_no=?";
		Object[] params = {usrNo};
		ResultSet rs = DbUtil.query(sql, params);
		try {
			if (rs.next()) {
				return rs.getInt("usr_per");
			} else {
				return 50;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 50;
	}
	//模糊查询，获取User的list
	public List<User> getUsersByusrName(String usrName){
		String sql = "select * from usr_user where usr_name like ?";
		Object[] params = {"%"+usrName+"%"};
		ResultSet rs = DbUtil.query(sql, params);
		List<User> users = new ArrayList<>();
		try {
			while (rs.next()) {
                User user = new User();
                user.setUsrEmail(rs.getString("usr_email"));
                user.setUsrName(rs.getString("usr_name"));
                user.setUsrId(rs.getInt("usr_id"));
                users.add(user);
            }
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return users;
	}
	//name查询，获取User
	public User getUserByusrName(String usrName){
		String sql = "select * from usr_user where usr_name = ?";
		Object[] params = {usrName};
		ResultSet rs = DbUtil.query(sql, params);
		try {
			if (rs.next()) {
				User user = new User();
				user.setUsrEmail(rs.getString("usr_email"));
				user.setUsrName(rs.getString("usr_name"));
				user.setUsrId(rs.getInt("usr_id"));
				return user;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return null;
	}
	//新增用户
	public int userAdd(User user) {
		String sql = "insert into usr_user(usr_no, usr_name, usr_pswd, usr_email, usr_tel) values(?, ?, md5(?), ? ,?)";
		Object[] params = { user.getUsrNo(), user.getUsrName(),
				user.getUsrPswd(), user.getUsrEmail(),user.getUsrTel() };
		return DbUtil.update(sql, params);
	}
	// 修改密码
	public int chgPswd(User user) {
		String sql = "update usr_user set usr_pswd = md5(?) where usr_no = ?";
		Object[] params = { user.getUsrPswd(), user.getUsrNo() };
		return DbUtil.update(sql, params);
	}

	// 保存用户信息修改
	public int userUpdateSave(User user) {
		String sql = "update usr_user set usr_name = ?, usr_tel = ?, usr_email = ? where  usr_no = ?";
		System.out
				.println("执行sql语句:update usr_user set usr_name = ?, usr_tel = ?, usr_email = ? where  usr_no = ?");
		Object[] params = { user.getUsrName(), user.getUsrTel(),
				user.getUsrEmail(), user.getUsrNo() };
		return DbUtil.update(sql, params);
	}

	// 检查用户账号是否已存在
	public int usrNoCheck(String usrNo) {
		String sql = "select usr_id from usr_user where usr_no=?";
		System.out.println("执行sql语句：select usr_id from usr_user where usr_no=?");
		Object[] params = {usrNo};
		ResultSet rs = DbUtil.query(sql, params);
		try {
			if (rs.next()) {
				return rs.getInt("usr_id");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}
}
