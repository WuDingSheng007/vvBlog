package com.vvblog.dao;

import com.vvblog.domain.Message;
import com.vvblog.domain.User;
import com.vvblog.jdbc.DbUtil;

import java.sql.Array;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * @program: vvblog
 * @description: Dao
 * @author: Li Qixuan
 * @create: 2019-08-09 15:45
 */
public class MessageDao {
    public int addMsg(Message msg){
        String sql = "insert into msg_message(pvt_rcv_id, pvt_send_id, prv_cont) values(?, ?, ?)";
        Object[] params = { msg.getPvtRcvId(), msg.getPvtSendId(),msg.getPvtCont()};
        return DbUtil.update(sql, params);
    }
    public List<Message> showMsg(Integer usrId)  {
        String sql = "SELECT prv_cont,pvt_send_id FROM msg_message where pvt_rcv_id = ?";
        Object[] params = {usrId};
        ResultSet rs = DbUtil.query(sql, params);
        List<Message> messages = new ArrayList<Message>();
        try {
            while (rs.next()){
                Message message = new Message();
                message.setPvtCont(rs.getString("prv_cont"));
                message.setPvtSendId(rs.getInt("pvt_send_id"));
                messages.add(message);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return messages;
    }
}
