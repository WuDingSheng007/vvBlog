package com.vvblog.dao;

/**
 * @program: vvblog
 * @description: Dao
 * @author: Li Qixuan
 * @create: 2019-08-09 15:45
 */
public class PrivateMessageDao {
}
