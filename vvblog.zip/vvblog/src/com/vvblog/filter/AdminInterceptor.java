package com.vvblog.filter;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * @program: vvblog
 * @description: 后台管理系统拦截器
 *
 * 	AdminInterceptor----拦截未登录的用户访问
 * 	拦截规则：
 * 		1.未登录用户直接拒绝访问，跳转首页
 * 		2.登录用户验证是否管理员权限，
 * 			若是，跳转adminlogin输入密码二次验证（通过id拿实例 然后取到对象中）usrAccount传入login.html
 *          若不是，跳转登录页面验证
 * @author: Li Qixuan
 * @create: 2019-08-09 21:49
 */
public class AdminInterceptor implements Filter {
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {

        //强转req,resp
        HttpServletRequest req = (HttpServletRequest) servletRequest;
        HttpServletResponse resp = (HttpServletResponse) servletResponse;

        final String uri = req.getRequestURI().startsWith("/admin") ? req.getRequestURI().substring(1) : req.getRequestURI();
        // 判断后台验证密码/资源/依赖相关url放行 + 资源
        if(uri.contains("/login") || uri.contains("/login.jsp")|| uri.contains("/images/")||uri.contains("/layui/")|| uri.contains("/fonts/")|| uri.contains("/js/")|| uri.contains("/css/")){
            filterChain.doFilter(req,resp);
            return;
        }

        //获取session中登录相关参数
        HttpSession session = req.getSession();
        boolean isLogin = false;
        String loginNo = "";
        if (session.getAttribute("isLogin")!=null)
            isLogin = (boolean) session.getAttribute("isLogin");
        boolean isLoginAdmin = false;
        if (session.getAttribute("isLoginAdmin")!=null)
            isLoginAdmin = (boolean) session.getAttribute("isLoginAdmin");
        if (session.getAttribute("loginNo")!=null)
            loginNo = (String) session.getAttribute("loginNo");

        //未登录跳转后台登录页面验证
        if (!isLogin){
            req.setAttribute("Msg",loginNo);
            req.getRequestDispatcher("/admin/login.jsp").forward(req,resp);
        }
        //后台已登录放行 后台未登录前台已登录跳转后台登录页面
        if (isLoginAdmin){
            System.out.println("[信息]["+session.getAttribute("loginNo")+"]后台拦截器放行");
            filterChain.doFilter(servletRequest,servletResponse);
        }else {
            req.setAttribute("Msg",loginNo);
            System.out.println("[信息]["+loginNo+"]跳转后台地址");
            req.getRequestDispatcher("/admin/login.jsp").forward(req,resp);
        }

    }

    @Override
    public void destroy() {

    }

}
