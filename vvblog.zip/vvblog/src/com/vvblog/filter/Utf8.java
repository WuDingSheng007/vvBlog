package com.vvblog.filter;

import javax.servlet.*;
import java.io.IOException;

/**
 * @program: vvblog
 * @description:
 * @author: Li Qixuan
 * @create: 2019-08-20 13:24
 */
public class Utf8 implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        //参数转换utf8
        servletRequest.setCharacterEncoding("utf-8");
        servletResponse.setCharacterEncoding("utf-8");
        //设置输出utf8
        servletResponse.setContentType("text/html; charset=UTF-8");

        filterChain.doFilter(servletRequest, servletResponse);
    }

    @Override
    public void destroy() {

    }
}
