package com.vvblog.domain;

/**
 * @program: vvblog
 * @description:
 *
 * 用户信息表实例
 * ID    usrId
 * 昵称  usrNikeName
 * 账号  usrNo
 * 密码  usrPswd
 * Email  usrEmail
 * tel    usrTel
 * 权限  usrPer
 * 状态[0/1 ]usrState
 * 关注数量  usrAttention
 *
 * @author: Li Qixuan
 * @create: 2019-08-09 13:08
 *
 */

public class User {

    private Integer usrId;
    private String usrName;
    private String usrNo;
    private String UsrPswd;
    private String usrEmail;
    private String usrTel;
    private String usrPer;
    private String usrState;
    private String usrAttention;

    public Integer getUsrId() {
        return usrId;
    }

    public void setUsrId(Integer usrId) {
        this.usrId = usrId;
    }

    public String getUsrName() {
        return usrName;
    }

    public void setUsrName(String usrName) {
        this.usrName = usrName;
    }

    public String getUsrNo() {
        return usrNo;
    }

    public void setUsrNo(String usrNo) {
        this.usrNo = usrNo;
    }

    public String getUsrPswd() {
        return UsrPswd;
    }

    public void setUsrPswd(String usrPswd) {
        UsrPswd = usrPswd;
    }

    public String getUsrEmail() {
        return usrEmail;
    }

    public void setUsrEmail(String usrEmail) {
        this.usrEmail = usrEmail;
    }

    public String getUsrTel() {
        return usrTel;
    }

    public void setUsrTel(String usrTel) {
        this.usrTel = usrTel;
    }

    public String getUsrPer() {
        return usrPer;
    }

    public void setUsrPer(String usrPer) {
        this.usrPer = usrPer;
    }

    public String getUsrState() {
        return usrState;
    }

    public void setUsrState(String usrState) {
        this.usrState = usrState;
    }

    public String getUsrAttention() {
        return usrAttention;
    }

    public void setUsrAttention(String usrAttention) {
        this.usrAttention = usrAttention;
    }

    public User() {

    }

    public User(String usrNo, String usrName, String usrPswd,
                String usrEmail) {
        super();
        this.usrNo = usrNo;
        this.usrName = usrName;
        this.UsrPswd = usrPswd;
        this.usrEmail = usrEmail;
    }
    public User(String usrName, String usrNo, String usrPswd, String usrEmail,
                String usrTel) {
        super();
        this.usrName = usrName;
        this.usrNo = usrNo;
        UsrPswd = usrPswd;
        this.usrEmail = usrEmail;
        this.usrTel = usrTel;
    }
}
