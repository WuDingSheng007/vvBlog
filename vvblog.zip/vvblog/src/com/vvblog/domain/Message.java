package com.vvblog.domain;

/**
 * @program: vvblog
 * @description:
 * pvt_private_message表对应
 * @author: Li Qixuan
 *
 * Id（主键）    pvtUsrId;
 * 内容         pvtCont;
 * 接受方id     pvtRcvId;
 * 发送用户id   pvtSendId;
 * 发送时间     pvtSendTime;
 * 已读状态     private Integer pvtReadState;
 *
 *
 * @create: 2019-08-09 15:31
 */
public class Message {
    private Integer pvtUsrId;
    private String pvtCont;
    private String pvtRcvId;
    private Integer pvtSendId;
    private String pvtSendTime;
    private String pvtReadState;



    public Message() {

    }

    public String getPvtCont() {
        return pvtCont;
    }

    public void setPvtCont(String pvtCont) {
        this.pvtCont = pvtCont;
    }

    public Integer getPvtUsrId() {
        return pvtUsrId;
    }

    public void setPvtUsrId(Integer pvtUsrId) {
        this.pvtUsrId = pvtUsrId;
    }

    public String getPvtRcvId() {
        return pvtRcvId;
    }

    public void setPvtRcvId(String pvtRcvId) {
        this.pvtRcvId = pvtRcvId;
    }

    public Integer getPvtSendId() {
        return pvtSendId;
    }

    public void setPvtSendId(Integer pvtSendId) {
        this.pvtSendId = pvtSendId;
    }

    public String getPvtSendTime() {
        return pvtSendTime;
    }

    public void setPvtSendTime(String pvtSendTime) {
        this.pvtSendTime = pvtSendTime;
    }

    public String getPvtReadState() {
        return pvtReadState;
    }

    public void setPvtReadState(String pvtReadState) {
        this.pvtReadState = pvtReadState;
    }
}
