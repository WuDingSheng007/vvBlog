package com.vvblog.service;

import com.vvblog.domain.User;

import java.util.List;

/**
 * @program: vvblog
 * @description: 用户信息表service
 * @author: Li Qixuan
 * @create: 2019-08-09 13:24
 */
public interface UserService {

    /*通过用户id获取user对象
    参数：Integer 返回值：User*/
    public abstract User selectUserById(Integer usrId);
    /*检查用户账号密码是否正确 */
    public abstract int loginCheck(String usrNo,String usrPswd);
    /*检查用户权限 */
    public abstract int getUsrPer(String usrNo);
    /*通过昵称拿对象(模糊)*/
    public List<User> getUsersByusrName(String usrName);
    /*通过昵称拿对象(模糊)*/
    public User getUserByusrName(String usrName);
    //通过user类新增用户
    public abstract int userAdd(User user);
    //修改密码，返回rs
    public abstract int chgPswd(User user);
    //保存用户信息修改,返回rs
    public abstract int userUpdateSave(User user);
    /*检查用户账号是否已存在 */
    public abstract int usrNoCheck(String usrNo);

}
