package com.vvblog.service;

/**
 * @program: vvblog
 * @description:
 * @author: Li Qixuan
 * @create: 2019-08-09 15:45
 */
public interface PrivateMessageService {
}
