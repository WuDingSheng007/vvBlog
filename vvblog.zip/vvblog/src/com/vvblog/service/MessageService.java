package com.vvblog.service;

        import com.vvblog.domain.Message;

        import java.util.List;

/**
 * @program: vvblog
        * @description:
        * @author: Li Qixuan
        * @create: 2019-08-09 15:45
        */
public interface MessageService {
    //添加私信
    boolean addMsg(Message msg);
    //获取本用户私信
    List<Message> showMsg(Integer usrId);

}
