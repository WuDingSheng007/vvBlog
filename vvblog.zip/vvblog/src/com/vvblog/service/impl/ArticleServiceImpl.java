package com.vvblog.service.impl;

import com.vvblog.dao.AttentionDao;
import com.vvblog.domain.*;

import java.util.List;
import java.util.Map;

import com.vvblog.dao.ArticleDao;
import com.vvblog.dao.UserDao;
import com.vvblog.service.ArticleService;

/**
 * @program: vvblog
 * @description: 实现ArticleService接口中的方法
 * @author 作者: Chen gm
 * @version 创建时间：2019年8月9日 下午4:07:40
 */
public class ArticleServiceImpl implements ArticleService {
	ArticleDao articleDao = new ArticleDao();

	public int insertAritcle(Article article,int usrId) {
		if (articleDao.insertAritcle(article) > 0) {
			List<Article> artList = articleDao.selectallArticleByUseid(usrId);
			int atcId = artList.get(artList.size() - 1).getAtcId();
			System.out.println("service 中atcId："+atcId);
			return atcId;
		}
		return 0;
	}

	public int insertAritcle(Article article) {
		return articleDao.insertAritcle(article);

	}


	public int selectatcIdByArticle(Article article) {
		return articleDao.selectatcIdByArticle(article);
	}

	public Article showArticleByActId(int actId) {

		return articleDao.showArticleByActId(actId);
	}

	public List<Article> selectallArticleByUseid(int usrId) {
		AttentionDao dao = new AttentionDao();
		List<Integer> integers = dao.selAtt(usrId);
		List<Article> articles = articleDao.selectallArticleByUseid(usrId);
		for (int i:integers) {
            if (articles != null&&i>0) {
                articles.addAll(articleDao.selectallArticleByUseid(i));
            }
        }
        return articles;
	}

	public int deleteArticleByatcAId(int atcId) {

		return articleDao.deleteArticleByatcAId(atcId);
	}

	public int updateArticleByActId(int atcId) {
		return articleDao.updateArticleByActId(atcId);
	}

	public int uploadPictureSave(int atcId, String fileName) {
		return articleDao.ploadPictureSave(atcId, fileName);

	}

	public List<Comment> selectCommList(int actId) {
		return articleDao.selectCommList(actId);
	}

	@Override
	public int selectCount() {
		return articleDao.selectCount();
	}

	@Override
	public List<Article> selectInfo(Map<String , Object> map) {
		return articleDao.selectInfo(map);
	}

    @Override
    public int insertComm(String cont, int atcId, int usrId) {
        return  articleDao.insertComm(cont, atcId, usrId);
    }
}
