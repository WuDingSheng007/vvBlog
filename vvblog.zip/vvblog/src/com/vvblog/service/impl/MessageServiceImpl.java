package com.vvblog.service.impl;

import com.vvblog.dao.MessageDao;
import com.vvblog.domain.Message;
import com.vvblog.service.MessageService;

import java.util.List;

/**
 * @program: vvblog
 * @description:
 * @author: Li Qixuan
 * @create: 2019-08-09 15:46
 */
public class MessageServiceImpl implements MessageService {
    MessageDao messageDao = new MessageDao();

    @Override
    public boolean addMsg(Message msg) {
        if (messageDao.addMsg(msg)>0){
            return true;
        }
        return false;
    }

    @Override
    public List<Message> showMsg(Integer usrId) {
        return messageDao.showMsg(usrId);
    }
}