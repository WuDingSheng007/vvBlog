package com.vvblog.service.impl;

import com.vvblog.dao.UserDao;
import com.vvblog.domain.User;
import com.vvblog.service.UserService;

import java.util.List;

/**
 * @program: vvblog
 * @description:
 * 实现UserService接口中的方法
 * @create: 2019-08-09 
 */
public class UserServiceImpl implements UserService {
    private UserDao userDao = new UserDao();

    @Override
    public User selectUserById(Integer usrId){
        return userDao.selectUserById(usrId);
    }

    @Override
    public int loginCheck(String usrNo, String usrPswd){
        return userDao.loginCheck(usrNo, usrPswd);
    }

    @Override
    public int getUsrPer(String usrNo){
        return userDao.getUsrPer(usrNo);
    }

    @Override
    public List<User> getUsersByusrName(String usrName) {
        return userDao.getUsersByusrName( usrName);
    }

    @Override
    public User getUserByusrName(String usrName) {
        return userDao.getUserByusrName( usrName);
    }

    @Override
    public int userAdd(User user){
        return userDao.userAdd(user);
    }
    public int chgPswd(User user){
        UserDao userDao = new UserDao();
        return userDao.chgPswd(user);
    }
    @Override
    public int userUpdateSave(User user){
        UserDao userDao = new UserDao();
        return userDao.userUpdateSave(user);
    }
    @Override
    public int usrNoCheck(String usrNo){
        UserDao userDao = new UserDao();
        return userDao.usrNoCheck(usrNo);
    }


}
