package com.vvblog.service.impl;

import com.vvblog.dao.AttentionDao;
import com.vvblog.domain.Attention;
import com.vvblog.service.AttentionService;

/** 
* @program: vvblog
* @description: 
* @author 作者: Chen gm 
* @version 创建时间：2019年8月9日 下午4:16:29 
*/
public class AttentionServiceImpl implements AttentionService {
	private AttentionDao  attentionDao = new AttentionDao();
	@Override
	public  Attention selectAttentionById(Integer attId) {
		return attentionDao.selectAttentionById(attId);
	}

	/*操作后返回当前状态*/
	@Override
	public boolean addAtt(Integer attId, Integer attFrdId) {
		if(attentionDao.selAtt(attId,attFrdId)){
				attentionDao.delAtt(attId,attFrdId);
				return false;
		}
		attentionDao.addAtt(attId,attFrdId);
		return true;
	}
}
