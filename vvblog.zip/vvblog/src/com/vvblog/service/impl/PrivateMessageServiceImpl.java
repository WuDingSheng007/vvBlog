package com.vvblog.service.impl;

import com.vvblog.dao.PrivateMessageDao;
import com.vvblog.service.PrivateMessageService;

/**
 * @program: vvblog
 * @description:
 * @author: Li Qixuan
 * @create: 2019-08-09 15:46
 */
public class PrivateMessageServiceImpl implements PrivateMessageService {
    PrivateMessageDao privateMessageDao = new PrivateMessageDao();
}
