package com.vvblog.service;

import java.util.List;
import java.util.Map;

import com.vvblog.domain.*;

/**
 * @program: vvblog
 * @description:文章信息表service
 * @author 作者: Chen gm
 * @version 创建时间：2019年8月9日 下午4:01:57
 *
 */
public interface ArticleService {

    //新增文章
    int insertAritcle(Article article);
    //通过文章对象查询文章id
    int selectatcIdByArticle(Article article);

    //通过当前usrId查询文章
    Article showArticleByActId(int usrId);

    //通过usrId 获取用户全部发文
    List<Article> selectallArticleByUseid(int usrId);
    //通过atcId 删除文章
    int deleteArticleByatcAId(int atcId);

    //同伙atcId 修改文章
    int updateArticleByActId(int atcId);

    //通过文章id获取所有评论集合
    List<Comment> selectCommList(int actId);

    //查询总数
    int selectCount();

    List<Article> selectInfo(Map<String, Object> map);

    int insertComm(String cont, int atcId, int usrId);
}


