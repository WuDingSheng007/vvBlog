package com.vvblog.controller;

import com.vvblog.service.impl.UserServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * @program: vvblog
 * @description: 后台系统登录验证
 * @author: Li Qixuan
 * @create: 2019-08-10 15:14
 */
public class AdminLogin extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String usrNo = req.getParameter("usrNo");
        String password = req.getParameter("password");
        System.out.println(usrNo+"+"+password);

        //调验证密码/获取权限方法,
        UserServiceImpl userService = new UserServiceImpl();
        if (userService.loginCheck(usrNo,password)!=0 && userService.getUsrPer(usrNo)==1){
            HttpSession session = req.getSession();
            session.setAttribute("isLoginAdmin",true);
        }

        resp.sendRedirect("/admin/");

    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }
}
