package com.vvblog.controller;
/** 
* @program: vvblog
* @description: 
* 删除文章
* @author 作者: Chen gm 
* @version 创建时间：2019年8月12日 下午2:27:35 
*/

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.vvblog.service.impl.ArticleServiceImpl;

public class DeleteArticleServlet extends HttpServlet{
	
	
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {		
		int	atcId = Integer.parseInt(req.getParameter("atcId"));
		System.out.println("delete:"+atcId);
		ArticleServiceImpl asImpl = new ArticleServiceImpl();
		//传入文章id
		int rel = asImpl.deleteArticleByatcAId(atcId);
		if(rel == 1) {
			System.err.println("删除成功");
			resp.sendRedirect("/showAllArticle");
			
		}else {
			System.err.println("删除失败");
		}
	}	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}
}
