package com.vvblog.controller;

import com.vvblog.domain.Message;
import com.vvblog.domain.User;
import com.vvblog.service.MessageService;
import com.vvblog.service.UserService;
import com.vvblog.service.impl.MessageServiceImpl;
import com.vvblog.service.impl.UserServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @program: vvblog
 * @description:
 * 私信发送页面
 * @author: Li Qixuan
 * @create: 2019-08-16 20:25
 */
public class AddMsg extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String pvtCont = req.getParameter("pvtCont");
        String usrName = req.getParameter("usrName");
        Message message = new Message();
        message.setPvtCont(pvtCont);
        UserService userService = new UserServiceImpl();
        User user = userService.getUserByusrName(usrName);
        if (user!=null){
            MessageService messageService = new MessageServiceImpl();
            Message msg = new Message();
            msg.setPvtCont(pvtCont);
            msg.setPvtRcvId(user.getUsrId().toString());
            msg.setPvtSendId((Integer) req.getSession().getAttribute("usrId"));
            if (messageService.addMsg(msg)){
                resp.getWriter().write("发送成功");
            }else {
                resp.getWriter().write("发送失败");
            }
        }



    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }
}
