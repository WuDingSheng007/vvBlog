package com.vvblog.controller;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.google.gson.Gson;
import com.vvblog.domain.Article;
import com.vvblog.service.impl.ArticleServiceImpl;
;

/**
 * @program: vvblog
 * @description: 文章创建写入数据库
 * @author 作者: Chen gm
 * @version 创建时间：2019年8月10日 下午2:51:45
 */
public class UpImg extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		
		
		if (!ServletFileUpload.isMultipartContent(req)) {// 检测是否为多媒体上传如果不是则停止
			resp.getWriter().println("Error: 表单必须包含 enctype=multipart/form-data");
			return;
		}

		DiskFileItemFactory factory = new DiskFileItemFactory();
		factory.setSizeThreshold(1024 * 1024 * 3);// 3M设置内存临界值-超过后将产生临时文件并存储于临时目录中
		factory.setRepository(new File(System.getProperty("java.io.tmpdir")));// 设置临时存储目录
		ServletFileUpload upload = new ServletFileUpload(factory);
		upload.setFileSizeMax(1024 * 1024 * 40);// 设置最大文件上传值 40M
		upload.setSizeMax(1024 * 1024 * 50);// 设置最大请求值 (包含文件和表单数据)50M
		// 构造临时路径来存储上传的文件 这个路径相对当前应用的目录
		ServletContext servletContext = getServletContext();
		String filePreix = "images";
		String uploadPath = servletContext.getRealPath("./") + filePreix;
		String fileName = "";
		File uploadDir = new File(uploadPath);
		if (!uploadDir.exists()) {// 如果目录不存在则创建
			uploadDir.mkdir();
		}

		try {
			List<FileItem> formItems = upload.parseRequest(req);
			if (formItems != null && formItems.size() > 0) {
				for (FileItem item : formItems) {// 处理表单中每一项内容
					if (!item.isFormField()) {// 处理不在表单中的字段
						fileName = new File(item.getName()).getName();
						SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddhhmmss");
						fileName = sdf.format(new Date()) + "-" + fileName;

						String filePath = uploadPath + File.separator + fileName;
						File storeFile = new File(filePath);
						System.out.println(filePath);// 在控制台输出文件的上传路径
						item.write(storeFile); // 保存文件到硬盘
						System.out.println("fileName:" + fileName);

						req.setAttribute("message", "文件上传成功!");
					}
				}
			}
		} catch (Exception ex) {
			req.setAttribute("message", "错误信息: " + ex.getMessage());
		}
		
		    Map<String,Object> map2=new HashMap<>();
		    Map<String,Object> map=new HashMap<>();
		    map.put("code",0);
		    map.put("msg","ok");
		    map.put("data",map2);
		    map2.put("src","/images/"+fileName);
		    
		    Gson gson = new Gson();
		    String json = gson.toJson(map);
		    resp.getWriter().write(json);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		doGet(req, resp);
	}

}
