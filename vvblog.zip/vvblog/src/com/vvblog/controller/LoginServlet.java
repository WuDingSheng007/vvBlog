package com.vvblog.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.vvblog.service.impl.UserServiceImpl;



/**
 * 用户登录 检查
 * 2019-8-10
 */
//spring mvc
public class LoginServlet extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String usrNo = req.getParameter("usrNo");
		String usrPswd = req.getParameter("usrPswd");
		String autoLogin = req.getParameter("autoLogin");
		System.out.println("autoLogin:"+autoLogin);
		HttpSession session = req.getSession();
		session.removeAttribute("loginNo");
		System.out.println("[信息]LoginServlet usrNo:" + usrNo + ",usrPswd:" + usrPswd);
			
		UserServiceImpl userServiceImpl = new UserServiceImpl();
		Integer usrId = userServiceImpl.loginCheck(usrNo,usrPswd);
		System.out.println(usrId);
			if (usrId!=0){
			session.setAttribute("loginNo", usrNo);
			session.setAttribute("usrId", usrId);
			session.setAttribute("isLogin", true);
			if ("on".equals(autoLogin)){
				Cookie cookie = new Cookie("autoLogin", "on");
				cookie.setMaxAge(3600*24*7);
				resp.addCookie(cookie);
				
				//记录登录编号和密码
				Cookie cookie2 = new Cookie("loginNo", usrNo);
				cookie2.setMaxAge(3600*24*7);
				resp.addCookie(cookie2);
				
				Cookie cookie3 = new Cookie("loginPswd", usrPswd);
				cookie3.setMaxAge(3600*24*7);
				resp.addCookie(cookie3);

			}else{

				Cookie cookie = new Cookie("autoLogin", "off");
				cookie.setMaxAge(3600*24*7);
				resp.addCookie(cookie);
				
				//记录登录编号和密码
				Cookie cookie2 = new Cookie("loginNo", "");
				cookie2.setMaxAge(0);
				resp.addCookie(cookie2);
				
				Cookie cookie3 = new Cookie("loginPswd", "");
				cookie3.setMaxAge(0);
				resp.addCookie(cookie3);

			}
			//req.getRequestDispatcher("index.jsp").forward(req, resp);
				resp.getWriter().write("登录成功");
		}else{

			//req.setAttribute("errMsg", "编号或密码有错，请重新登录");
			//req.getRequestDispatcher("userMgr/userLogin.jsp").forward(req, resp);
				resp.getWriter().write("登录失败");

		}
	}
}
