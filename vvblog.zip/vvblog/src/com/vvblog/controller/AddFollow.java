package com.vvblog.controller;

import com.vvblog.service.impl.AttentionServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * @program: vvblog
 * @description: 增加关注
 * 传入参数：要关注的用户id
 * 返回关注结果
 * AjAx实现
 * @author: Li Qixuan
 * @create: 2019-08-11 19:58
 */
public class AddFollow extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println(Integer.parseInt(req.getParameter("usrId")));
        int frdId = Integer.parseInt(req.getParameter("usrId"));
        HttpSession session = req.getSession();
        int usrId = (int) session.getAttribute("usrId");
        AttentionServiceImpl attentionService = new AttentionServiceImpl();
        PrintWriter out = resp.getWriter();
        resp.setContentType("text/text;charset=utf-8");
        resp.setCharacterEncoding("UTF-8");
        if (attentionService.addAtt(usrId,frdId)){
            out.write("1");
        }else{
            out.write("0");
        }

    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }
}
