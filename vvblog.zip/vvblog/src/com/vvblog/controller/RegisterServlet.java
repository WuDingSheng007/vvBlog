package com.vvblog.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.vvblog.domain.User;
import com.vvblog.service.impl.UserServiceImpl;

/**
 * 用户注册
 */
public class RegisterServlet extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String usrNo = req.getParameter("usrNo");
		String usrName = req.getParameter("usrName");
		String usrPswd = req.getParameter("usrPswd");
		String usrPswd2 = req.getParameter("usrPswd2");
		String usrEmail = req.getParameter("usrEmail");
		String teltest = req.getParameter("teltest");
		String usrTel = req.getParameter("usrTel");
		HttpSession session = req.getSession();
		String sms = (String) session.getAttribute(usrTel);
		String msg = "";

		System.out.println("sms:"+sms);
		System.out.println("usrTel:"+usrTel);
		System.out.println("teltest:"+teltest);
		System.out.println(teltest.equals(sms));

		if (usrNo == null || usrNo.length() == 0){
			msg += "账号不能为空";
		}

		if (!teltest.equals(sms)){
			msg += "验证码错误";
		}
		UserServiceImpl userServiceImpl = new UserServiceImpl();
		if(userServiceImpl.usrNoCheck(usrNo)!=0){
			msg += "账号已被注册";
		}
		if (usrName == null || usrName.length() == 0)
			msg += "\n昵称不能为空";
		if (usrPswd == null || usrPswd.length() < 6)
			msg += "\n密码必须大于6位";
		if (usrPswd != null && !usrPswd.equals(usrPswd2))
			msg += "\n两次输入密码不同";
		if (msg.length() > 0) {
			req.setAttribute("errMsg", msg);
			req.getRequestDispatcher("userMgr/userRegister.jsp").forward(req,
					resp);
			return;
		}
		User user = new User(usrNo, usrName, usrPswd, usrEmail);
		user.setUsrTel(usrTel);
		int rel = userServiceImpl.userAdd(user);
		System.out.println("新注册:" + rel);
		
		req.getRequestDispatcher("userMgr/RegisterAfter.jsp").forward(req, resp);
	}
}