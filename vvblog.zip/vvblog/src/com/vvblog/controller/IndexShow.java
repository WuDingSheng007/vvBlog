package com.vvblog.controller;

import com.google.gson.Gson;
import com.vvblog.domain.Article;
import com.vvblog.service.ArticleService;
import com.vvblog.service.impl.ArticleServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @program: vvblog
 * @description:
 * 显示当前用户的所有发文
 * @author 作者: Chen gm
 * @version 创建时间：2019年8月12日 上午12:50:41
 */
public class IndexShow extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String page = "1";
        if(req.getParameter("page")!=null && req.getParameter("page").length()>0)
	        page = req.getParameter("page");// 当前页
        System.out.println(page);
		String size = "5";// 条shu

		int pages = Integer.parseInt(page);
		int rows = Integer.parseInt(size);
		int pageIndex = (pages - 1) * rows;
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("page", pageIndex);// 起始条数
		map.put("size", rows);// 每页条数

        ArticleService service = new ArticleServiceImpl();
        // 查询总数
		int count = service.selectCount();

		if (count > 0) {
			List<Article> info = service.selectInfo(map);
            req.setAttribute("articleList", info);
            req.setAttribute("page",page);
            int max = count/5;
            if (count%5>0){
                max += 1;
            }
            req.setAttribute("pageMax",max);
            req.getRequestDispatcher("/index.jsp").forward(req,resp);
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}

}
