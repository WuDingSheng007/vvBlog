package com.vvblog.controller;

import java.io.File;
import java.io.IOException;
import java.nio.channels.SeekableByteChannel;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.vvblog.domain.Article;
import com.vvblog.service.impl.ArticleServiceImpl;
;

/**
 * @program: vvblog
 * @description: 文章创建写入数据库
 * @author 作者: Chen gm
 * @version 创建时间：2019年8月10日 下午2:51:45
 */
public class WriteArticleServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// 获得文章的标题和内容图片地址和当前登录用户
		String atcTitle = req.getParameter("atcTitle");
		String atcCont = req.getParameter("atcCont");
		String subtxt = req.getParameter("subtxt");
		System.out.println("con层数据测试"+atcTitle+atcTitle+subtxt);//测试数据
		HttpSession session = req.getSession();
		if (session.getAttribute("usrId")==null){
			resp.getWriter().write("未登录不能发文");
			return;
		}
		int usrId = (int) session.getAttribute("usrId");
		//int usrId = 1;
		ArticleServiceImpl asImpl = new ArticleServiceImpl();
		// 封装取得的数据
		Article article = new Article();
		article.setActUserId(usrId);
		article.setAtcTitle(atcTitle);
		article.setAtcCont(atcCont);
		article.setAtcImgPath(subtxt);
		System.out.println(article.toString());

		int atcId = asImpl.insertAritcle(article,usrId);
		if (atcId > 0) {
			System.err.println("插入成功");
			resp.sendRedirect("/showAllArticle");
		} else {
			System.err.println("插入失败");
		}
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}

}
