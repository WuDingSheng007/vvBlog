package com.vvblog.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.vvblog.service.impl.ArticleServiceImpl;

/** 
* @program: vvblog
* @description: 
* @author 作者: Chen gm 
* @version 创建时间：2019年8月12日 下午3:23:32 
*/
	public class UpdateArticleServlet extends HttpServlet{
		
		
		protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
			String actIdStr = req.getParameter("actId");
			System.out.println(actIdStr);
			int atcId = 1;
			if( actIdStr != null ) {
				atcId = Integer.parseInt(actIdStr);
			}
			ArticleServiceImpl asImpl = new ArticleServiceImpl();
			int rel = asImpl.updateArticleByActId(atcId);
		}
		
		
		protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
			doGet(req, resp);
		}

}
