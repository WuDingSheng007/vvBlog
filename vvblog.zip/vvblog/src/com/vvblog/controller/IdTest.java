package com.vvblog.controller;

import com.vvblog.service.impl.UserServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * @program: vvblog
 * @description:
 * @author: Li Qixuan
 * @create: 2019-08-20 10:12
 */
public class IdTest extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String usrNo = req.getParameter("usrNo");
        UserServiceImpl userServiceImpl = new UserServiceImpl();
        if(userServiceImpl.usrNoCheck(usrNo)!=0){
            resp.getWriter().write("has");
        }else{
            resp.getWriter().write("none");
        }

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
}