package com.vvblog.controller;
/** 
* @program: vvblog
* @description:
* 显示用户文章 
* @author 作者: Chen gm 
* @version 创建时间：2019年8月11日 下午6:29:08 
*/

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.vvblog.domain.Article;
import com.vvblog.domain.Comment;
import com.vvblog.service.ArticleService;
import com.vvblog.service.impl.ArticleServiceImpl;

public class ShowArticleServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String atcIdStr = req.getParameter("atcId");
        int atcId = Integer.parseInt(atcIdStr);
        ArticleService asImpl = new ArticleServiceImpl();
        //通过文章id 查询 文章对象
        Article showArticle = asImpl.showArticleByActId(atcId);
        List<Comment> commList = asImpl.selectCommList(atcId);
        if(	showArticle != null ) {
            req.setAttribute("commList", commList);
            req.setAttribute("showArticle",showArticle);
            req.getRequestDispatcher("/datails.jsp").forward(req, resp);
        }else {
            System.err.println("查询文章失败");
        }
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}
}
