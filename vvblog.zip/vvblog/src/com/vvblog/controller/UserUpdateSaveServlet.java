package com.vvblog.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;




import javax.servlet.http.HttpSession;

import com.vvblog.domain.User;
import com.vvblog.service.UserService;
import com.vvblog.service.impl.UserServiceImpl;

public class UserUpdateSaveServlet extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		
		String usrName = req.getParameter("usrName");
		String usrTel = req.getParameter("usrTel");
		String usrEmail = req.getParameter("usrEmail");
		HttpSession session = req.getSession();
		String usrNo = (String) session.getAttribute("loginNo");
		String msg = "";
		if (usrName == null || usrName.length() == 0)
			msg += "编号不能为空";
		if (usrEmail == null || usrEmail.length() == 0)
			msg += "邮箱不能为空";
		if (msg.length() > 0){
			req.setAttribute("errMsg", msg);
			req.getRequestDispatcher("userMgr/userUpdate.jsp").forward(req, resp);
			return;
		}
		
		UserService userServiceImpl = new UserServiceImpl();
		User user = new User(usrName,usrNo,"", usrEmail,usrTel);
		int rel = userServiceImpl.userUpdateSave(user);
		System.out.println("修改信息:"+rel);
		
		req.getRequestDispatcher("userMgr/updataOk.jsp").forward(req, resp);
	}
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doPost(req, resp);
	}
}
