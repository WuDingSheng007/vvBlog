package com.vvblog.controller;

import com.vvblog.domain.User;
import com.vvblog.service.impl.UserServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * @program: vvblog
 * @description:
 * @author: Li Qixuan
 * @create: 2019-08-11 18:42
 */
public class GetUserByUsrName extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String usrName = req.getParameter("usrName");
        UserServiceImpl userService = new UserServiceImpl();
        List<User> users = userService.getUsersByusrName(usrName);
        req.setAttribute("users",users);
        for (User user :users) {
            System.out.println(user.getUsrEmail());
        }
        System.out.println(users);
        req.getRequestDispatcher("/userMgr/susers.jsp").forward(req,resp);

    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }
}
