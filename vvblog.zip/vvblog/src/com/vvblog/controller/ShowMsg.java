package com.vvblog.controller;

import com.vvblog.domain.Message;
import com.vvblog.service.impl.MessageServiceImpl;
import org.w3c.dom.ls.LSException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

/**
 * @program: vvblog
 * @description: 展示私信
 * @create: 2019-08-20 20:28
 */
public class ShowMsg extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        Integer usrId = (Integer) session.getAttribute("usrId");
        MessageServiceImpl service = new MessageServiceImpl();
        List<Message> messages = service.showMsg(usrId);
        req.setAttribute("msgs",messages);
        req.getRequestDispatcher("userMgr/showMsg.jsp").forward(req,resp);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }
}
