package com.vvblog.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.vvblog.service.ArticleService;
import com.vvblog.service.impl.ArticleServiceImpl;
import com.vvblog.service.impl.UserServiceImpl;

/** 
* @program: vvblog
* @description: 
* @author 作者: Chen gm 
* @version 创建时间：2019年8月19日 上午11:21:15 
*/
public class InsertComServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String cont = req.getParameter("desc");
		System.out.println(cont);
		HttpSession session = req.getSession();
		//int usrId = (Integer)session.getAttribute("usrId");
		int usrId = 1;
		String atcIdStr = req.getParameter("atcId");
		System.out.println("actIdStr:"+atcIdStr);
		int atcId = Integer.parseInt(atcIdStr);
	    //int atcId = 4;
	    
	    ArticleService asImpl = new ArticleServiceImpl();
	    int rel = asImpl.insertComm(cont,atcId,usrId);
		if(rel>0) {
			System.out.println("评论插入成功");
			req.getRequestDispatcher("/Article/datails.jsp").forward(req, resp);
		}
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}
}
