﻿package com.vvblog.controller;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * @program: vvblog
 * @description:
 * @create: 2019-08-20 23:04
 */
public class SMStest extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Integer re = (int)((Math.random()*9+1)*1000);
        String tel = req.getParameter("tel");
        String PostData = "account=&password=&mobile="+tel+"&content="+java.net.URLEncoder.encode("您的验证码是：【"+re+"】。请不要把验证码泄露给其他人。如非本人操作，可不用理会！");
        System.out.println(PostData);
        HttpSession session = req.getSession();

        session.setAttribute(tel,re.toString());
        String ret = Send.SMS(PostData, "http://sms.106jiekou.com/utf8/sms.aspx");
        resp.getWriter().write(ret);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }


}
