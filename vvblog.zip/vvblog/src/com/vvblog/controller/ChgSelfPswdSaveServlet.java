package com.vvblog.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.vvblog.domain.User;
import com.vvblog.service.impl.UserServiceImpl;

public class ChgSelfPswdSaveServlet extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {

		String oldPswd = req.getParameter("oldPswd");
		String newPswd = req.getParameter("newPswd");
		String newPswdConfirm = req.getParameter("newPswdConfirm");

		String msg = "";
		if (oldPswd == null || oldPswd.length() == 0)
			msg += "请输入原密码";
		if (newPswd == null || newPswd.length() == 0)
			msg += "\n请输入新密码";
		if (newPswd != null && !newPswd.equals(newPswdConfirm))
			msg += "\n两次输入密码不同";

		// 检查原密码是否正确
		HttpSession session = req.getSession();
		String loginNo = (String) session.getAttribute("loginNo");

		UserServiceImpl userService = new UserServiceImpl();
		if (userService.loginCheck(loginNo, oldPswd) == 0) {
			msg += "\n原密码不正确";
		}
		if (loginNo == null || loginNo.length() == 0) {
			msg += "\n请先登录";
		}
		if (msg.length() > 0) {
			// 如果有错误信息，则跳转回修改密码界面
			req.setAttribute("errMsg", msg);
			req.getRequestDispatcher("userMgr/chgSelfPswd.jsp").forward(req,
					resp);
			return;
		}

		User user = new User(loginNo, "", newPswd, "");
		int rel = userService.chgPswd(user);
		System.out.println("修改密码:" + rel);

		session.removeAttribute("loginNo");
		req.getRequestDispatcher("userMgr/chgSelfPswdAfter.jsp").forward(req,
				resp);
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doPost(req, resp);
	}
}
