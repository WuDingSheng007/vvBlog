package com.vvblog.controller;

import com.google.gson.Gson;
import com.vvblog.domain.User;
import com.vvblog.service.UserService;
import com.vvblog.service.impl.UserServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

/**
 * @program: vvblog
 * @description:
 * @author: Li Qixuan
 * @create: 2019-08-14 19:04
 */
public class SearchWord extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //获得关键字
        String word = req.getParameter("word");

        //查询该关键字的所有用户
        UserService service = new UserServiceImpl();
        List<User> users = service.getUsersByusrName(word);


        //["xiaomi","huawei",""...]

        //谷歌的json转换工具转换为Json对象
        Gson gson = new Gson();
        String json = gson.toJson(users);

        System.out.println(json);

        resp.setContentType("text/html;charset=UTF-8");
        //返回ajax（json类型）
        resp.getWriter().write(json);

    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }
}
