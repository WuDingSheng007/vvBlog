package com.vvblog.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.vvblog.domain.Article;
import com.vvblog.service.impl.ArticleServiceImpl;
import com.vvblog.service.impl.AttentionServiceImpl;

/**
 * @program: vvblog
 * @description:
 * 显示当前用户的所有发文
 * @author 作者: Chen gm
 * @version 创建时间：2019年8月12日 上午12:50:41
 */
public class showAllArticleServlet extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session = req.getSession();
		Integer usrId = (Integer) session.getAttribute("usrId");
		if (usrId==null||usrId==0){
			resp.sendRedirect("/vvblog/userMgr/userLogin.jsp");
			return;
		}
		System.out.println("id"+session.getAttribute("usrId"));
		ArticleServiceImpl asImpl = new ArticleServiceImpl();
        List<Article> articleList = asImpl.selectallArticleByUseid(usrId);
		if(	articleList	!=	null ) {
			req.setAttribute("articleList", articleList);
			req.getRequestDispatcher("/index.jsp").forward(req, resp);
		}else {
			System.err.println("查询文章失败");
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}

}
